# Terms of Service

**Last updated: October 4, 2024**

Welcome to UmaAssistant (hereinafter referred to as "the Application"). Before using the Application, please read the following terms of service (hereinafter referred to as "the Terms") carefully. By using the Application, you agree to comply with these Terms.

## 1. Acceptance of Terms
By using the Application, you agree to comply with these Terms. If you do not agree with these Terms, please do not use the Application.

## 2. License
You are granted a non-exclusive, non-transferable right to use the Application. You may not use the content of the Application for any illegal or unauthorized purposes.

## 3. User Obligations
- You agree to comply with all applicable laws and regulations.
- You shall keep your account and password confidential and are responsible for all activities that occur under your account.
- You must not disseminate any illegal, harmful, or offensive content.

## 4. Intellectual Property Rights
The Application and its content (including but not limited to text, graphics, trademarks, etc.) are the property of the developer and are protected by relevant laws. You may not use, copy, or modify any content without authorization.

## 5. Privacy Policy
We value your privacy. For more information, please refer to our [Privacy Policy](https://play.google.com/store/apps/datasafety?id=com.kakuun.umaassistant).

## 6. Limitation of Liability
The developer is not liable for any losses or damages resulting from the use of the Application. The Application is provided on an "as-is" basis, and the developer does not guarantee its reliability, availability, or suitability. The developer shall not be liable for any type of account blockage resulting from the use of the Application.

## 7. Modification of Terms
The developer reserves the right to modify these Terms at any time. You should regularly check these Terms for updates.

## 8. Contact Information
If you have any questions regarding these Terms, please contact us at:
- Email: hxfgfg333@gmail.com

Thank you for using the Application!
