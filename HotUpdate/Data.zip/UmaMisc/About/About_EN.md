# About This Application

## About UmaAssistant
This application (UmaAssistant) is an unofficial app for the game Umamusume: Pretty Derby. It is operated to provide necessary features and information to make the gameplay more convenient.

## About Copyright and Related Handling
This application does not intend to infringe on any copyrights. The images and information displayed in this application are for the convenience of the app users, with no intention of violating copyright. If there are any copyright concerns, please contact us through the following contact information, and we will take action as soon as possible.

## Contact Information
hxfgfg333@gmail.com
