"use strict";
var DISTANCE_PATTERN = new RegExp("(.+)~(.+)");
var Distance = (function () {
    function Distance(start, end, length) {
        this.start = start;
        this.end = end;
        this.length = length;
    }
    return Distance;
}());
function GetDistance(distance) {
    var match = distance.match(DISTANCE_PATTERN);
    var startDistance = match[1];
    var endDistance = match[2];
    return new Distance(parseInt(startDistance), parseInt(endDistance), parseInt(endDistance) - parseInt(startDistance));
}
function GetPercentage(numerator, denominator) {
    return "".concat((numerator / denominator * 100).toString(), "%");
}
function CreateDistanceLabel(element, distance, distanceValue) {
    var distanceLabel = document.createElement("div");
    distanceLabel.className = "race_graphics_distance_label";
    distanceLabel.innerHTML = (distanceValue) ? distanceValue.toString() : distance.start.toString();
    distanceLabel.style.display = "none";
    if (distance.start === 0)
        distanceLabel.style.display = "none";
    var interval = setInterval(function () {
        if (element) {
            clearInterval(interval);
            if (distance.start > 0)
                distanceLabel.style.display = "flex";
            var elementRect = element.getBoundingClientRect();
            var distanceLabelRect = distanceLabel.getBoundingClientRect();
            distanceLabel.style.left = "-".concat((distanceLabelRect.width - (distanceLabelRect.width / 2) + 3).toString(), "px");
            distanceLabel.style.top = "".concat((elementRect.height - distanceLabelRect.height + 6).toString(), "px");
        }
    }, 100);
    element.appendChild(distanceLabel);
}
function SortRaceGraphicsBlock(raceElement) {
    var e = Array.from(raceElement.querySelectorAll(".race_graphics_block"));
    e.sort(function (a, b) {
        var aDistance = parseInt(a.querySelector(".race_graphics_distance_label").textContent);
        var bDistance = parseInt(b.querySelector(".race_graphics_distance_label").textContent);
        return aDistance - bDistance;
    });
    raceElement.innerHTML = "";
    e.forEach(function (element) { return raceElement.appendChild(element); });
}
function UpdateRaceGraphics(raceGraphicsType, data) {
    var race_construction = data[raceGraphicsType]["champions_meeting"]["race_construction"];
    var totalDistance = parseInt(data[raceGraphicsType]["champions_meeting"]["race_distance"]);
    var race_slope = document.querySelector(".race_slope");
    var racecourse_construction = document.querySelector(".racecourse_construction");
    var race_phase = document.querySelector(".race_phase");
    var race_effect_phase = document.querySelector(".race_effect_phase");
    race_slope.innerHTML = "";
    racecourse_construction.innerHTML = "";
    race_phase.innerHTML = "";
    race_effect_phase.innerHTML = "";
    for (var const_title in race_construction) {
        var distance_list = race_construction[const_title];
        var distance = new Distance();
        for (var distance_idx in distance_list) {
            var slope = document.createElement("div");
            var racecourse_const = document.createElement("div");
            var phase = document.createElement("div");
            var distance_value = distance_list[distance_idx];
            if (const_title === "序盤" || const_title === "中盤" || const_title === "終盤" ||
                const_title === "初期" || const_title === "中期" || const_title === "後期") {
                distance = GetDistance(distance_value);
                phase.className = const_title === "序盤" || const_title === "初期" ? "race_graphics_block jyoban" :
                    const_title === "中盤" || const_title === "中期" ? "race_graphics_block cyuban" :
                        "race_graphics_block syuban";
                phase.textContent = const_title;
                phase.style.width = GetPercentage(distance.length, totalDistance);
                CreateDistanceLabel(phase, distance);
            }
            if (const_title === "コーナー" || const_title === "最終コーナー" ||
                const_title === "直線" || const_title === "最終直線" ||
                const_title === "彎道" || const_title === "最終彎道") {
                distance = GetDistance(distance_value);
                racecourse_const.className = const_title === "直線" ? "race_graphics_block straight" :
                    const_title === "コーナー" || const_title === "彎道" ? "race_graphics_block corner" :
                        const_title === "最終コーナー" || const_title === "最終彎道" ? "race_graphics_block final_corner" :
                            "race_graphics_block final_straight";
                racecourse_const.textContent = const_title;
                racecourse_const.style.width = GetPercentage(distance.length, totalDistance);
                CreateDistanceLabel(racecourse_const, distance);
            }
            else if (const_title === "上り坂" || const_title === "下り坂" ||
                const_title === "上坡" || const_title === "下坡") {
                distance = GetDistance(distance_value);
                slope.className = const_title === "上り坂" || const_title === "上坡" ? "race_graphics_ruler up_slope" : "race_graphics_ruler down_slope";
                slope.textContent = const_title;
                slope.style.width = GetPercentage(distance.length, totalDistance);
                slope.style.left = GetPercentage(distance.start, totalDistance);
            }
            race_phase.appendChild(phase);
            race_slope.appendChild(slope);
            racecourse_construction.appendChild(racecourse_const);
        }
    }
    for (var i = 0; i < 3; ++i) {
        var block = document.createElement("div");
        if (i == 0) {
            var jyobanDistance = new Distance();
            var cyubanDistance = new Distance();
            block.className = "race_graphics_block position_keep";
            switch (raceGraphicsType) {
                case RaceGraphicsType.JP:
                    {
                        block.textContent = "ポジションキープ区間";
                        jyobanDistance = GetDistance(race_construction["序盤"][0]);
                        cyubanDistance = GetDistance(race_construction["中盤"][0]);
                        break;
                    }
                case RaceGraphicsType.TW:
                    {
                        block.textContent = "保持位置區間";
                        jyobanDistance = GetDistance(race_construction["初期"][0]);
                        cyubanDistance = GetDistance(race_construction["中期"][0]);
                        break;
                    }
            }
            block.style.width = GetPercentage(jyobanDistance.length + (cyubanDistance.length / 2), totalDistance);
            block.style.left = GetPercentage(jyobanDistance.start, totalDistance);
        }
        else if (i == 1) {
            var cyubanDistance = new Distance();
            var syubanDistance = new Distance();
            block.textContent = "";
            block.className = "race_graphics_block empty_block";
            switch (raceGraphicsType) {
                case RaceGraphicsType.JP:
                    {
                        cyubanDistance = GetDistance(race_construction["中盤"][0]);
                        syubanDistance = GetDistance(race_construction["終盤"][0]);
                        break;
                    }
                case RaceGraphicsType.TW:
                    {
                        cyubanDistance = GetDistance(race_construction["中期"][0]);
                        syubanDistance = GetDistance(race_construction["後期"][0]);
                        break;
                    }
            }
            block.style.width = GetPercentage((cyubanDistance.length / 2) + (syubanDistance.length / 2), totalDistance);
            block.style.left = GetPercentage(0, totalDistance);
            CreateDistanceLabel(block, cyubanDistance, (cyubanDistance.length / 2) + (syubanDistance.length / 2));
        }
        else if (i == 2) {
            var jyobanDistance = new Distance();
            var cyubanDistance = new Distance();
            var syubanDistance = new Distance();
            block.className = "race_graphics_block last_spurt";
            switch (raceGraphicsType) {
                case RaceGraphicsType.JP:
                    {
                        block.textContent = "ラストスパート";
                        jyobanDistance = GetDistance(race_construction["序盤"][0]);
                        cyubanDistance = GetDistance(race_construction["中盤"][0]);
                        syubanDistance = GetDistance(race_construction["終盤"][0]);
                        break;
                    }
                case RaceGraphicsType.TW:
                    {
                        block.textContent = "最後衝刺";
                        jyobanDistance = GetDistance(race_construction["初期"][0]);
                        cyubanDistance = GetDistance(race_construction["中期"][0]);
                        syubanDistance = GetDistance(race_construction["後期"][0]);
                        break;
                    }
            }
            block.style.width = GetPercentage(syubanDistance.length / 2, totalDistance);
            block.style.left = GetPercentage(0, totalDistance);
            CreateDistanceLabel(block, syubanDistance, jyobanDistance.length + cyubanDistance.length + (syubanDistance.length / 2));
        }
        race_effect_phase.appendChild(block);
    }
    SortRaceGraphicsBlock(race_phase);
    SortRaceGraphicsBlock(racecourse_construction);
}
window.addEventListener("message", function (message) {
    if (message.data["message_type"] === WebMessageType.SEND_RACE_EVENT_INFORMATION_DATA) {
        race_event_information_data = message.data["content"];
    }
    else if (message.data["message_type"] === WebMessageType.UPDATE_RACE_GRAPHICS) {
        UpdateRaceGraphics(message.data["content"]["race_graphics_type"], message.data["content"]["race_event_information_data"]);
    }
});
