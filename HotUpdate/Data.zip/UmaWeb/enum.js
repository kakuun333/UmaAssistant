"use strict";
var AndroidCountry;
(function (AndroidCountry) {
    AndroidCountry["JP"] = "JP";
    AndroidCountry["TW"] = "TW";
    AndroidCountry["CN"] = "CN";
    AndroidCountry["US"] = "US";
})(AndroidCountry || (AndroidCountry = {}));
var ApplicationLanguage;
(function (ApplicationLanguage) {
    ApplicationLanguage["JP"] = "ja";
    ApplicationLanguage["TW"] = "zh-Hant-TW";
    ApplicationLanguage[ApplicationLanguage["EN"] = 2] = "EN";
})(ApplicationLanguage || (ApplicationLanguage = {}));
var GameServerType;
(function (GameServerType) {
    GameServerType[GameServerType["JP"] = 0] = "JP";
    GameServerType[GameServerType["TW"] = 1] = "TW";
})(GameServerType || (GameServerType = {}));
var JpServerLanguage;
(function (JpServerLanguage) {
    JpServerLanguage[JpServerLanguage["JP"] = 0] = "JP";
    JpServerLanguage[JpServerLanguage["TW"] = 1] = "TW";
})(JpServerLanguage || (JpServerLanguage = {}));
var JsonDataType;
(function (JsonDataType) {
    JsonDataType["EVENT_DATA_JP"] = "event_data_jp";
    JsonDataType["EVENT_DATA_TW"] = "event_data_tw";
    JsonDataType["SKILL_DATA_JP"] = "skill_data_jp";
    JsonDataType["SKILL_DATA_TW"] = "skill_data_tw";
    JsonDataType["SKILL_DATA_JP_TRANS_TW"] = "skill_data_jp_trans_tw";
    JsonDataType["SELECT_CHARACTER_DATA"] = "select_character_data";
    JsonDataType["RACE_EVENT_INFORMATION_DATA"] = "race_event_information_data";
})(JsonDataType || (JsonDataType = {}));
var WebMessageType;
(function (WebMessageType) {
    WebMessageType["CHARACTER_IMAGE_CLICKED"] = "CharacterImageClicked";
    WebMessageType["SAVE_RACE_SCHEDULE_DATA"] = "SaveRaceScheduleData";
    WebMessageType["LOAD_RACE_SCHEDULE_DATA"] = "LoadRaceScheduleData";
    WebMessageType["SEND_RACE_EVENT_INFORMATION_DATA"] = "SendRaceEventInformationData";
    WebMessageType["UPDATE_RACE_GRAPHICS"] = "UpdateRaceGraphics";
})(WebMessageType || (WebMessageType = {}));
var UmaColor;
(function (UmaColor) {
    UmaColor["UMA_BLUE"] = "rgb(85, 118, 120)";
    UmaColor["UMA_DARK_PURPLE"] = "rgb(107, 85, 136)";
})(UmaColor || (UmaColor = {}));
var SkillDataType;
(function (SkillDataType) {
    SkillDataType["SKILL_EFFECT"] = "skill_effect";
    SkillDataType["SKILL_CONDITION"] = "skill_condition";
})(SkillDataType || (SkillDataType = {}));
var RaceGraphicsType;
(function (RaceGraphicsType) {
    RaceGraphicsType["JP"] = "jp";
    RaceGraphicsType["TW"] = "tw";
})(RaceGraphicsType || (RaceGraphicsType = {}));
