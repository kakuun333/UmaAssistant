"use strict";
function ReadJson(jsonPath, callback) {
    var READY_STATE_DONE = 4;
    var STATUS_SUCCESS = 200;
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === READY_STATE_DONE) {
            if (xhr.status === STATUS_SUCCESS) {
                var jsonData = JSON.parse(xhr.responseText);
                callback(jsonData);
            }
            else {
                console.error('readJson Error:', xhr.statusText);
            }
        }
    };
    xhr.open('GET', jsonPath, true);
    xhr.send();
}
function IsMobileDevice() {
    return (navigator.userAgent.toLowerCase().match(/android|webos|iphone|ipad|ipod|blackberry|windows phone/i)) ? true : false;
}
function IsAndroidDevice() {
    return (navigator.userAgent.toLowerCase().match(/android/i)) ? true : false;
}
function IsWindowsDevice() {
    return (navigator.userAgent.toLowerCase().match(/windows/i)) ? true : false;
}
function HiraganaToKatakana(hiragana) {
    return hiragana.replace(/[\u3041-\u3096]/g, function (match) {
        var chr = match.charCodeAt(0) + 0x60;
        return String.fromCharCode(chr);
    });
}
function GetSize(element) {
    var _rect = element.getBoundingClientRect();
    var _width = _rect.right - _rect.left;
    var _height = _rect.bottom - _rect.top;
    var tmp = {
        width: _width,
        height: _height
    };
    return tmp;
}
function DisableContextMenu() {
    document.addEventListener("contextmenu", function (e) { e.preventDefault(); }, false);
}
