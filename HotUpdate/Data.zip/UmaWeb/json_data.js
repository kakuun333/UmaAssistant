"use strict";
var skill_data_jp = null;
var skill_data_tw = null;
var skill_data_jp_trans_tw = null;
var enhance_skill_data_jp = null;
var enhance_skill_data_tw = null;
var select_character_data = null;
var race_data_jp = null;
var race_event_information_data = null;
function SetJsonData(dataVariableName, value) {
    switch (dataVariableName) {
        case JsonDataType.SKILL_DATA_JP:
            skill_data_jp = value;
            break;
        case JsonDataType.SKILL_DATA_TW:
            skill_data_tw = value;
            break;
        case JsonDataType.SKILL_DATA_TW:
            skill_data_jp_trans_tw = value;
            break;
        case JsonDataType.SELECT_CHARACTER_DATA:
            select_character_data = value;
            break;
        case JsonDataType.RACE_EVENT_INFORMATION_DATA:
            race_event_information_data = value;
            break;
    }
}
