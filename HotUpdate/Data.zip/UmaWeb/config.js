"use strict";
var Config = {
    GameServer: GameServerType.JP,
    JpServerLanguage: JpServerLanguage.JP,
    ApplicationLanguage: undefined,
};
function SetGameServer(gameServerType) {
    Config.GameServer = gameServerType;
}
function SetJpServerLanguage(jpServerLanguage) {
    Config.JpServerLanguage = jpServerLanguage;
}
function SetApplicationLanguage(value) {
    Config.ApplicationLanguage = value;
}
