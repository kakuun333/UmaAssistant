"use strict";
var null_tw_event_owner_pattern = new RegExp("<tw_event_owner>null</tw_event_owner>");
function ClearCharacterImageButton() {
    var icon_container = document.getElementById("icon_container");
    icon_container.innerHTML = "";
}
function CreateCharacterImageButton(jp_event_owner, tw_event_owner, charImgName) {
    var icon_container = document.getElementById("icon_container");
    var charImg = document.createElement("img");
    charImg.className = "character_icon";
    charImg.src = "../UmaMisc/Image/Character/".concat(charImgName, ".png");
    charImg.alt = "<jp_event_owner>".concat(jp_event_owner, "</jp_event_owner><tw_event_owner>").concat(tw_event_owner, "</tw_event_owner>");
    charImg.loading = "eager";
    charImg.draggable = false;
    if (IsAndroidDevice()) {
        charImg.addEventListener("click", function (event) {
            Android.onCharacterIconClick(charImg.src, charImg.alt);
        });
    }
    else if (IsWindowsDevice()) {
        charImg.addEventListener("click", function (event) {
            var msgObj = {
                MessageType: WebMessageType.CHARACTER_IMAGE_CLICKED,
                Src: charImg.src,
                Alt: charImg.alt,
                ImageFileName: charImgName,
            };
            window.chrome.webview.postMessage(JSON.stringify(msgObj));
        });
    }
    icon_container.appendChild(charImg);
}
function SetupSearchTextbox() {
    var search_title = document.getElementById("search_title");
    var search_textbox = document.getElementById("search_textbox");
    if (IsMobileDevice()) {
        search_title.style.height = "10vh";
        search_textbox.parentElement.style.height = "10vh";
    }
    search_textbox.addEventListener("input", function () {
        var search_pattern = new RegExp("".concat(search_textbox.value, "|").concat(HiraganaToKatakana(search_textbox.value)), "i");
        var character_icon_elements = document.querySelectorAll(".character_icon");
        for (var i = 0; i < character_icon_elements.length; i++) {
            var char_icon = character_icon_elements[i];
            if (char_icon.alt.match(search_pattern)) {
                if (char_icon.classList.contains("is_search_filter_hide"))
                    char_icon.classList.remove("is_search_filter_hide");
            }
            else {
                char_icon.classList.add("is_search_filter_hide");
            }
        }
    });
}
function ReflushCharacterElement() {
    if (select_character_data == null)
        return;
    ClearCharacterImageButton();
    for (var idx in select_character_data) {
        var item = select_character_data[idx];
        CreateCharacterImageButton(item.jp_event_owner, item.tw_event_owner, item.icon);
    }
}
function ChangeSelectCharacterHtmlLanguage(language) {
    var search_title = document.getElementById("search_title");
    var search_textbox = document.getElementById("search_textbox");
    var filter_text_label = document.getElementById("filter_text_label");
    var jp_filter_btn = document.getElementById("jp_filter_btn");
    var tw_filter_btn = document.getElementById("tw_filter_btn");
    if (language == ApplicationLanguage.JP || language == AndroidCountry.JP) {
        search_title.innerHTML = "キャラ検索";
        search_textbox.placeholder = "クリックで検索";
        filter_text_label.innerHTML = "フィルター";
        jp_filter_btn.innerHTML = "日本";
        tw_filter_btn.innerHTML = "台湾・香港";
    }
    else if (language == ApplicationLanguage.TW || language == AndroidCountry.TW) {
        search_title.innerHTML = "角色査詢";
        search_textbox.placeholder = "點擊此處輸入角色名稱";
        filter_text_label.innerHTML = "篩選";
        jp_filter_btn.innerHTML = "日服";
        tw_filter_btn.innerHTML = "繁中服";
    }
    else if (language == ApplicationLanguage.EN || language == AndroidCountry.US) {
        search_title.innerHTML = "Search Character";
        search_textbox.placeholder = "Click to search character";
        filter_text_label.innerHTML = "Filter";
        jp_filter_btn.innerHTML = "JP";
        tw_filter_btn.innerHTML = "TW/HK";
    }
}
function LoadSelectCharacterData() {
    if (select_character_data === null) {
        console.log("Loading select_character_data...");
        setTimeout(LoadSelectCharacterData, 100);
    }
    else {
        console.log("Loaded select_character_data !!");
        ReflushCharacterElement();
    }
}
function SetupImgAlign() {
    var icon_container = document.getElementById("icon_container");
    if (IsMobileDevice()) {
        icon_container.style.textAlign = "center";
    }
    else if (IsWindowsDevice()) {
        icon_container.style.textAlign = "left";
    }
}
function FilterImage(GameServer) {
    var icon_container = document.getElementById("icon_container");
    for (var _i = 0, _a = Array.from(icon_container.children); _i < _a.length; _i++) {
        var element = _a[_i];
        var char_img = element;
        if (GameServer == "jp") {
            if (char_img.classList.contains("is_gameserver_filter_hide"))
                char_img.classList.remove("is_gameserver_filter_hide");
        }
        else if (GameServer == "tw") {
            if (char_img.alt.match(null_tw_event_owner_pattern)) {
                if (!char_img.classList.contains("is_gameserver_filter_hide"))
                    char_img.classList.add("is_gameserver_filter_hide");
            }
        }
    }
}
function SetupFilterButtons() {
    var jp_filter_btn = document.getElementById("jp_filter_btn");
    var tw_filter_btn = document.getElementById("tw_filter_btn");
    jp_filter_btn.addEventListener("click", function () {
        jp_filter_btn.classList.add("ua_btn_selected");
        tw_filter_btn.classList.remove("ua_btn_selected");
        FilterImage("jp");
    });
    tw_filter_btn.addEventListener("click", function () {
        jp_filter_btn.classList.remove("ua_btn_selected");
        tw_filter_btn.classList.add("ua_btn_selected");
        FilterImage("tw");
    });
}
LoadSelectCharacterData();
DisableContextMenu();
SetupImgAlign();
SetupSearchTextbox();
SetupFilterButtons();
