"use strict";
var UNKNOWN_DATE_PATTERN = new RegExp("(.+)月(.+)旬");
var KNOWN_DATE_PATTERN = new RegExp("(\\d+)/(\\d+)|(\\d+)月(\\d+)日");
function GetRaceEventDate(eventDate) {
    var result = String();
    var targetMonth = undefined;
    var targetDay = undefined;
    var TARGET_HOUR = 12;
    var unknown_date_match = eventDate.match(UNKNOWN_DATE_PATTERN);
    var known_date_match = eventDate.match(KNOWN_DATE_PATTERN);
    if (unknown_date_match) {
        return unknown_date_match[0];
    }
    else if (known_date_match) {
        targetMonth = known_date_match[1] !== undefined ? parseInt(known_date_match[1]) - 1 : parseInt(known_date_match[3]) - 1;
        targetDay = known_date_match[2] !== undefined ? parseInt(known_date_match[2]) : parseInt(known_date_match[4]);
    }
    var nowDate = Date.now();
    var currentDate = new Date(nowDate);
    var year = currentDate.getFullYear();
    var targetDate = new Date(year, targetMonth, targetDay, TARGET_HOUR);
    var daysDiff = Math.floor((targetDate.getTime() - currentDate.getTime()) / (1000 * 60 * 60 * 24));
    if (Config.ApplicationLanguage == ApplicationLanguage.JP || Config.ApplicationLanguage == AndroidCountry.JP) {
        result = "\u3042\u3068".concat(daysDiff.toString(), "\u65E5");
    }
    else if (Config.ApplicationLanguage == ApplicationLanguage.TW || Config.ApplicationLanguage == AndroidCountry.TW) {
        result = "\u9084\u6709".concat(daysDiff.toString(), "\u5929");
    }
    else if (Config.ApplicationLanguage == ApplicationLanguage.EN || Config.ApplicationLanguage == AndroidCountry.US) {
        result = "".concat(daysDiff.toString(), " Days left");
    }
    console.log("result: ".concat(result));
    return result;
}
function RaceInfoTitleToReadable(infoTitle) {
    var result = null;
    switch (infoTitle) {
        case "racecourse":
            result = (Config.ApplicationLanguage === ApplicationLanguage.JP || Config.ApplicationLanguage === AndroidCountry.JP) ? "競馬場" : "賽馬場";
            break;
        case "race_distance":
            result = (Config.ApplicationLanguage === ApplicationLanguage.JP || Config.ApplicationLanguage === AndroidCountry.JP) ? "距離" : "距離";
            break;
        case "race_distance_type":
            result = (Config.ApplicationLanguage === ApplicationLanguage.JP || Config.ApplicationLanguage === AndroidCountry.JP) ? "距離種類" : "距離分類";
            break;
        case "race_track":
            result = (Config.ApplicationLanguage === ApplicationLanguage.JP || Config.ApplicationLanguage === AndroidCountry.JP) ? "バ場状態" : "馬場狀態";
            break;
        case "race_direction":
            result = (Config.ApplicationLanguage === ApplicationLanguage.JP || Config.ApplicationLanguage === AndroidCountry.JP) ? "方向" : "方向";
            break;
        case "race_weather":
            result = (Config.ApplicationLanguage === ApplicationLanguage.JP || Config.ApplicationLanguage === AndroidCountry.JP) ? "天候" : "天氣";
            break;
        case "race_season":
            result = (Config.ApplicationLanguage === ApplicationLanguage.JP || Config.ApplicationLanguage === AndroidCountry.JP) ? "季節" : "季節";
            break;
    }
    return result;
}
function UpdateRaceEventInformation(raceGraphicsType) {
    var race_info_container = document.getElementById("race_info_container");
    var race_event_date = document.getElementById("race_event_date");
    var jp_button = document.getElementById("jp_button");
    var tw_button = document.getElementById("tw_button");
    var champions_meeting_button = document.getElementById("champions_meeting_button");
    var league_of_heros_button = document.getElementById("league_of_heros_button");
    var game_server_type_text_label = document.getElementById("game_server_type_text_label");
    var race_event_type_text_label = document.getElementById("race_event_type_text_label");
    race_info_container.innerHTML = "";
    race_event_date.textContent = GetRaceEventDate(race_event_information_data[raceGraphicsType]["champions_meeting"]["race_date"]);
    for (var infoTitle in race_event_information_data[raceGraphicsType]["champions_meeting"]) {
        if (infoTitle === "race_date" || infoTitle === "race_construction")
            continue;
        var infoValue = race_event_information_data[raceGraphicsType]["champions_meeting"][infoTitle];
        var race_info_block = document.createElement("div");
        race_info_block.id = infoTitle;
        race_info_block.className = "race_info_block";
        race_info_block.innerHTML = "\n            <div class=\"race_info_title\">".concat(RaceInfoTitleToReadable(infoTitle), "</div>\n            <div class=\"race_info_value\">").concat(infoValue, "</div>\n        ");
        race_info_container.append(race_info_block);
    }
    if (Config.ApplicationLanguage === ApplicationLanguage.JP || Config.ApplicationLanguage === AndroidCountry.JP) {
        champions_meeting_button.innerHTML = "チャンピオンズミーティング";
        league_of_heros_button.innerHTML = "リーグ オブ ヒーローズ";
        game_server_type_text_label.innerHTML = "ゲームサーバー";
        jp_button.innerHTML = "日本";
        tw_button.innerHTML = "台湾．香港";
        race_event_type_text_label.innerHTML = "レースイベント";
    }
    else if (Config.ApplicationLanguage === ApplicationLanguage.TW || Config.ApplicationLanguage === AndroidCountry.TW) {
        champions_meeting_button.innerHTML = "冠軍集會";
        league_of_heros_button.innerHTML = "群英聯賽";
        game_server_type_text_label.innerHTML = "遊戲伺服器";
        jp_button.innerHTML = "日服";
        tw_button.innerHTML = "繁中服";
        race_event_type_text_label.innerHTML = "競賽活動類型";
    }
    SendMessageToIFrame("race_graphics", WebMessageType.UPDATE_RACE_GRAPHICS, {
        "race_graphics_type": raceGraphicsType,
        "race_event_information_data": race_event_information_data,
    });
    if (raceGraphicsType === RaceGraphicsType.JP) {
        jp_button.classList.add("ua_btn_selected");
        tw_button.classList.remove("ua_btn_selected");
    }
    else {
        jp_button.classList.remove("ua_btn_selected");
        tw_button.classList.add("ua_btn_selected");
    }
}
function SetupButton() {
    var jp_button = document.getElementById("jp_button");
    var tw_button = document.getElementById("tw_button");
    jp_button.addEventListener("click", function () { return UpdateRaceEventInformation(RaceGraphicsType.JP); });
    tw_button.addEventListener("click", function () { return UpdateRaceEventInformation(RaceGraphicsType.TW); });
}
function SendMessageToIFrame(iframeId, messageType, content) {
    var iframe = document.getElementById(iframeId);
    iframe.contentWindow.postMessage({
        "message_type": messageType,
        "content": content
    }, "*");
}
if (IsWindowsDevice()) {
    ReadJson("race_event_information_data.json", function (jsonData) {
        race_event_information_data = jsonData;
        UpdateRaceEventInformation(RaceGraphicsType.JP);
    });
    Config.ApplicationLanguage = ApplicationLanguage.JP;
}
var interval = setInterval(function () {
    if (race_event_information_data) {
        clearInterval(interval);
        SendMessageToIFrame("race_graphics", WebMessageType.SEND_RACE_EVENT_INFORMATION_DATA, race_event_information_data);
        SendMessageToIFrame("race_graphics", WebMessageType.UPDATE_RACE_GRAPHICS, {
            "race_graphics_type": RaceGraphicsType.JP,
            "race_event_information_data": race_event_information_data,
        });
    }
}, 100);
SetupButton();
