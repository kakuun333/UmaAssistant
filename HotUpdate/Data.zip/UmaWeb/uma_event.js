"use strict";
function CreateChoice(choice_name, choice_effect) {
    if (IsAndroidDevice()) {
        choice_name = decodeURIComponent(choice_name);
        choice_effect = decodeURIComponent(choice_effect);
    }
    var choice_table = document.getElementById("choice_table");
    var title_tr = document.createElement("tr");
    var th = document.createElement("th");
    th.innerHTML = choice_name;
    th.className = "choice_name";
    title_tr.appendChild(th);
    choice_table.appendChild(title_tr);
    var effect_tr = document.createElement("tr");
    var td = document.createElement("td");
    td.innerHTML = choice_effect;
    td.className = "choice_effect";
    effect_tr.appendChild(td);
    choice_table.appendChild(effect_tr);
}
function ChangeEventName(text) {
    if (IsAndroidDevice())
        text = decodeURIComponent(text);
    var event_name = document.getElementById("event_name");
    event_name.innerHTML = text;
}
function ChangeEventOwner(text) {
    if (IsAndroidDevice())
        text = decodeURIComponent(text);
    var event_owner = document.getElementById("event_owner");
    event_owner.innerHTML = text;
}
function CleanChoiceTable() {
    var choice_table = document.getElementById("choice_table");
    while (choice_table.firstChild) {
        choice_table.removeChild(choice_table.firstChild);
    }
}
function ChangeChoiceHtmlLanguage(language) {
    var event_owner_title = document.getElementById("event_owner_title");
    var event_name_title = document.getElementById("event_name_title");
    var skill_pt_title = document.getElementById("skill_pt_title");
    var skill_description_title = document.getElementById("skill_description_title");
    var upper_skill_title = document.getElementById("upper_skill_title");
    var lower_skill_title = document.getElementById("lower_skill_title");
    var skill_effect_title = document.getElementById("skill_effect_title");
    var skill_condition_title = document.getElementById("skill_condition_title");
    if (language == ApplicationLanguage.JP || language == AndroidCountry.JP) {
        event_owner_title.innerHTML = "イベント所有者";
        event_name_title.innerHTML = "イベント";
        skill_pt_title.innerHTML = "スキルpt";
        skill_description_title.innerHTML = "説明文";
        upper_skill_title.innerHTML = "上位スキル";
        lower_skill_title.innerHTML = "下位スキル";
        skill_effect_title.innerHTML = "効果";
        skill_condition_title.innerHTML = "発動条件";
    }
    else if (language == ApplicationLanguage.TW || language == AndroidCountry.TW) {
        event_owner_title.innerHTML = "事件所有者";
        event_name_title.innerHTML = "事件名稱";
        skill_pt_title.innerHTML = "所需技能點";
        skill_description_title.innerHTML = "描述";
        upper_skill_title.innerHTML = "上位技能";
        lower_skill_title.innerHTML = "下位技能";
        skill_effect_title.innerHTML = "效果";
        skill_condition_title.innerHTML = "發動條件";
    }
    else if (language == ApplicationLanguage.EN || language == AndroidCountry.US) {
        event_owner_title.innerHTML = "Event Owner";
        event_name_title.innerHTML = "Event Name";
        skill_pt_title.innerHTML = "Skill Point";
        skill_description_title.innerHTML = "Description";
        upper_skill_title.innerHTML = "Upper-level Skill";
        lower_skill_title.innerHTML = "Lower-level Skill";
        skill_effect_title.innerHTML = "Effect";
        skill_condition_title.innerHTML = "Cast Condition";
    }
}
function SetFontSize(fontSize) {
    document.documentElement.style.setProperty("--font-size", fontSize.toString() + "rem");
}
function SetSkillInformationFontSize(fontSize) {
    document.documentElement.style.setProperty("--skill-info-font-size", fontSize.toString() + "rem");
}
function SetBackgroundTransparency(alpha) {
    document.documentElement.style.setProperty("--background-color", "rgba(16, 25, 43, ".concat(alpha, ")"));
}
if (IsWindowsDevice()) {
    document.body.style.userSelect = "text";
}
else {
    document.body.style.userSelect = "none";
}
DisableContextMenu();
