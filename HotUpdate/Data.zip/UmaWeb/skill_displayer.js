"use strict";
function CreateEnhanceData(skillDataType, enhanceDataTitle, enhanceDataData) {
    var rootElement = undefined;
    var label = document.createElement("div");
    label.className = "skill_hint_label";
    var title = document.createElement("div");
    title.innerHTML = enhanceDataTitle;
    var data = document.createElement("div");
    data.innerHTML = enhanceDataData;
    switch (skillDataType) {
        case SkillDataType.SKILL_EFFECT:
            rootElement = document.getElementById("skill_effect_table");
            title.className = "skill_effect_title";
            data.className = "skill_effect";
            break;
        case SkillDataType.SKILL_CONDITION:
            rootElement = document.getElementById("skill_condition_table");
            title.className = "skill_condition_title";
            data.className = "skill_condition";
            break;
    }
    label.appendChild(title);
    label.appendChild(data);
    rootElement.appendChild(label);
}
function CleanEnhanceDataTable() {
    var skill_effect_table = document.getElementById("skill_effect_table");
    var skill_condition_table = document.getElementById("skill_condition_table");
    while (skill_effect_table.lastChild) {
        skill_effect_table.removeChild(skill_effect_table.lastChild);
    }
    while (skill_condition_table.lastChild) {
        skill_condition_table.removeChild(skill_condition_table.lastChild);
    }
}
function FindSkillData(event, skill_hint) {
    var layout_skill_hint = document.getElementById("layout_skill_hint");
    var skill_icon = document.getElementById("skill_icon");
    var skill_name = document.getElementById("skill_name");
    var skill_pt = document.getElementById("skill_pt");
    var skill_description = document.getElementById("skill_description");
    var upper_skill = document.getElementById("upper_skill");
    var lower_skill = document.getElementById("lower_skill");
    var upper_skill_title = document.getElementById("upper_skill_title");
    var lower_skill_title = document.getElementById("lower_skill_title");
    var skill_effect_title = document.getElementById("skill_effect_title");
    var skill_condition_title = document.getElementById("skill_condition_title");
    var skill_hint_body = document.getElementById("skill_hint_body");
    var skill_hint_pattern = new RegExp("<span class=\"skill_hint\"(.+)?>『(.+)』");
    var skill_data = null;
    switch (Config.GameServer) {
        case GameServerType.JP:
            switch (Config.JpServerLanguage) {
                case JpServerLanguage.JP:
                    skill_data = skill_data_jp;
                    break;
                case JpServerLanguage.TW:
                    skill_data = skill_data_jp_trans_tw;
                    break;
            }
            break;
        case GameServerType.TW:
            skill_data = skill_data_tw;
            break;
    }
    for (var skill_rare in skill_data) {
        var rare_obj = skill_data[skill_rare];
        for (var json_skill_name in rare_obj) {
            var skill_name_obj = rare_obj[json_skill_name];
            var match_skill_name = skill_hint.outerHTML.match(skill_hint_pattern);
            if (json_skill_name == match_skill_name[2]) {
                skill_name.innerText = json_skill_name;
                if (skill_rare == "rare") {
                    layout_skill_hint.style.background = 'linear-gradient(to right,  rgb(254, 242, 176), rgb(254, 195, 57))';
                }
                else if (skill_rare == "normal") {
                    layout_skill_hint.style.background = 'linear-gradient(to right,  rgb(248, 248, 248), rgb(199, 199, 212))';
                }
                if (skill_name_obj["pt"] != undefined) {
                    skill_pt.innerText = skill_name_obj["pt"];
                }
                else {
                }
                if (skill_name_obj["description"] != undefined) {
                    var description = skill_name_obj["description"];
                    skill_description.innerText = description;
                    var computedStyle = getComputedStyle(skill_icon);
                    var skillIconWidthPx = parseFloat(computedStyle.width);
                    var skillIconWidthInRem = parseFloat(computedStyle.width) / parseFloat(getComputedStyle(document.documentElement).fontSize);
                    var calculatedWidth = description.length + skillIconWidthInRem + "rem";
                    var remToPx = parseFloat(getComputedStyle(document.documentElement).fontSize);
                    var calculatedWidthPx = description.length * remToPx + skillIconWidthPx;
                    var windowWidth_1 = window.innerWidth;
                    if (calculatedWidthPx > windowWidth_1) {
                        layout_skill_hint.style.width = windowWidth_1 + "px";
                    }
                    else {
                        layout_skill_hint.style.width = calculatedWidth;
                    }
                }
                if (skill_name_obj["icon"] != undefined) {
                    skill_icon.src = "../UmaMisc/Image/Skill/".concat(skill_name_obj["icon"], ".png");
                }
                if (skill_name_obj["upper_skill"] != undefined) {
                    upper_skill.innerText = skill_name_obj["upper_skill"];
                    upper_skill_title.parentElement.style.display = "flex";
                }
                else {
                    upper_skill_title.parentElement.style.display = "none";
                }
                if (skill_name_obj["lower_skill"] != undefined) {
                    lower_skill.innerText = skill_name_obj["lower_skill"];
                    lower_skill_title.parentElement.style.display = "flex";
                }
                else {
                    lower_skill_title.parentElement.style.display = "none";
                }
                CleanEnhanceDataTable();
                if (skill_name_obj["effect"] != undefined) {
                    for (var skill_data_title in skill_name_obj["effect"]) {
                        var skill_data_data = skill_name_obj["effect"][skill_data_title];
                        CreateEnhanceData(SkillDataType.SKILL_EFFECT, skill_data_title, skill_data_data);
                    }
                }
                else {
                    skill_effect_title.style.display = "none";
                }
                if (skill_name_obj["condition"] != undefined) {
                    for (var skill_data_title in skill_name_obj["condition"]) {
                        var skill_data_data = skill_name_obj["condition"][skill_data_title];
                        CreateEnhanceData(SkillDataType.SKILL_CONDITION, skill_data_title, skill_data_data);
                    }
                }
                else {
                    skill_condition_title.style.display = "none";
                }
            }
        }
    }
    var mouseX = event.clientX;
    var mouseY = event.clientY;
    layout_skill_hint.style.top = mouseY + 'px';
    layout_skill_hint.style.bottom = '0px';
    layout_skill_hint.style.left = mouseX + 'px';
    layout_skill_hint.style.right = '0px';
    layout_skill_hint.style.display = "inline";
    var windowWidth = window.innerWidth;
    var windowHeight = window.innerHeight;
    var rect = layout_skill_hint.getBoundingClientRect();
    var skill_table_size = GetSize(layout_skill_hint);
    if (rect.left + skill_table_size.width > windowWidth) {
        var horizontal_offset = (rect.left + skill_table_size.width) - windowWidth;
        layout_skill_hint.style.left = parseInt(layout_skill_hint.style.left) - horizontal_offset + "px";
        layout_skill_hint.style.right = parseInt(layout_skill_hint.style.right) - horizontal_offset + "px";
    }
    if (rect.top + skill_table_size.height > windowHeight) {
        var vertical_offset = (rect.top + skill_table_size.height) - windowHeight;
        layout_skill_hint.style.top = parseInt(layout_skill_hint.style.top) - vertical_offset + "px";
        layout_skill_hint.style.bottom = parseInt(layout_skill_hint.style.bottom) - vertical_offset + "px";
    }
}
function UpdateSkillContent() {
    var layout_skill_hint = document.getElementById("layout_skill_hint");
    var skill_hint_elements = document.querySelectorAll(".skill_hint");
    var _loop_1 = function (i) {
        var skill_hint = skill_hint_elements[i];
        if (IsMobileDevice()) {
            skill_hint.style.fontSize = "1.2em";
            skill_hint.addEventListener("touchstart", function (event) {
                FindSkillData(event, skill_hint);
            });
            skill_hint.addEventListener("touchend", function (event) {
                layout_skill_hint.style.display = "none";
            });
        }
        else {
            skill_hint.addEventListener("mouseenter", function (event) {
                FindSkillData(event, skill_hint);
            });
            skill_hint.addEventListener("mouseleave", function (event) {
                layout_skill_hint.style.display = "none";
            });
        }
    };
    for (var i = 0; i < skill_hint_elements.length; i++) {
        _loop_1(i);
    }
}
function HideSkillHintContent() {
    var layout_skill_hint = document.getElementById("layout_skill_hint");
    layout_skill_hint.style.display = "none";
}
if (IsWindowsDevice()) {
    ReadJson("../UmaData/skill_data_jp.json", function (jsonData) {
        skill_data_jp = jsonData;
    });
    ReadJson("../UmaData/skill_data_tw.json", function (jsonData) {
        skill_data_tw = jsonData;
    });
    ReadJson("../UmaData/skill_data_jp_trans_tw.json", function (jsonData) {
        skill_data_jp_trans_tw = jsonData;
    });
}
UpdateSkillContent();
